class MyRoutes {
  static String drawerRoute = "/drawer";
  static String homeRoute = "/home";
  static String homeDetailsRoute = "/detail";
  static String cartRoute = "/cart";
  static String playerRoute = "/player";
  static String welcomeRoute = "/welcome";
}
